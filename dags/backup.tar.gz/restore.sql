--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sample_database;
--
-- Name: sample_database; Type: DATABASE; Schema: -; Owner: yudi
--

CREATE DATABASE sample_database WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE sample_database OWNER TO yudi;

\connect sample_database

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mock_cars; Type: TABLE; Schema: public; Owner: yudi
--

CREATE TABLE public.mock_cars (
    id integer,
    car_name character varying(50),
    maker character varying(50),
    year_manufactured character varying(50),
    color character varying(50),
    owner_contact character varying(50)
);


ALTER TABLE public.mock_cars OWNER TO yudi;

--
-- Name: mock_stocks_data; Type: TABLE; Schema: public; Owner: yudi
--

CREATE TABLE public.mock_stocks_data (
    id integer,
    stock_market character varying(500),
    stock_market_cap character varying(500),
    stock_name character varying(500)
);


ALTER TABLE public.mock_stocks_data OWNER TO yudi;

--
-- Name: mock_users; Type: TABLE; Schema: public; Owner: yudi
--

CREATE TABLE public.mock_users (
    id integer,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(50),
    gender character varying(50),
    ip_address character varying(20)
);


ALTER TABLE public.mock_users OWNER TO yudi;

--
-- Data for Name: mock_cars; Type: TABLE DATA; Schema: public; Owner: yudi
--

COPY public.mock_cars (id, car_name, maker, year_manufactured, color, owner_contact) FROM stdin;
\.
COPY public.mock_cars (id, car_name, maker, year_manufactured, color, owner_contact) FROM '$$PATH$$/3255.dat';

--
-- Data for Name: mock_stocks_data; Type: TABLE DATA; Schema: public; Owner: yudi
--

COPY public.mock_stocks_data (id, stock_market, stock_market_cap, stock_name) FROM stdin;
\.
COPY public.mock_stocks_data (id, stock_market, stock_market_cap, stock_name) FROM '$$PATH$$/3256.dat';

--
-- Data for Name: mock_users; Type: TABLE DATA; Schema: public; Owner: yudi
--

COPY public.mock_users (id, first_name, last_name, email, gender, ip_address) FROM stdin;
\.
COPY public.mock_users (id, first_name, last_name, email, gender, ip_address) FROM '$$PATH$$/3254.dat';

--
-- PostgreSQL database dump complete
--

